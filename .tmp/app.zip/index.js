import { default as collectionNumberFunctions_1_0 } from './functions/collection-number-functions/1.0';
import { default as collectionPropertyExpression_1_0 } from './functions/collection-property-expression/1.0';
import { default as collectionSum_1_0 } from './functions/collection-sum/1.0';

const fn = {
  "collectionNumberFunctions 1.0": collectionNumberFunctions_1_0,
  "collectionPropertyExpression 1.0": collectionPropertyExpression_1_0,
  "collectionSum 1.0": collectionSum_1_0,
};

export default fn;
