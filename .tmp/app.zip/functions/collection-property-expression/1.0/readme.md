Firstly select a collection and the proprty you want to modify. By default the checkbox "Upsert to database" is unchecked, if you want to instantly update the collection to the database, check it.

In the expression you can use the "property" variable to get the current collection property value. This allows you to insert other variables and dynamically change the property based on the value.

The result will be the modified collection.
